from main.Run import run_process

def enterModel():
   run_process()