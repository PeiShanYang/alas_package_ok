from main.Main import main

def enter():
    main()