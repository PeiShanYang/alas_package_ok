class ResultStorage:
    saveFinalDictPth = {"switch": False}
    saveFinalScriptPth = {"switch": False}
    saveFinalOnnx = {"switch": False}
    saveBestDictPth = {"switch": True}    
    saveBestScriptPth = {"switch": False}
    saveBestOnnx = {"switch": True}
    saveCheckpoint = {"switch": False, "saveIter": 1}
    savePredictResult = {"switch": True}
    saveWrongFile = {"switch": True}