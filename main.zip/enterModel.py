from main.Run import run_process

if __name__ == '__main__':
   run_process()